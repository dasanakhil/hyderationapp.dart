import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const HydroFlowApp());
}

class HydroFlowApp extends StatelessWidget {
  const HydroFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HydroFlow',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F9FF),
      ),
      home: const HomeScreen(),
    );
  }
}

// ----------------------------------------------------------
// WATER RECORD MODEL
// ----------------------------------------------------------

class WaterRecord {
  final int amount;
  final DateTime time;

  WaterRecord({
    required this.amount,
    required this.time,
  });
}

// ----------------------------------------------------------
// HOME SCREEN
// ----------------------------------------------------------

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int waterIntake = 0;
  int dailyGoal = 2500;

  List<WaterRecord> records = [];

  @override
  void initState() {
    super.initState();
    loadWaterData();
  }

  // Load saved values
  Future<void> loadWaterData() async {
    final prefs = await SharedPreferences.getInstance();

    final savedDate = prefs.getString('date');
    final today = getDateString(DateTime.now());

    // Reset water when a new day starts
    if (savedDate != today) {
      await prefs.setInt('water', 0);
      await prefs.setString('date', today);
    }

    setState(() {
      waterIntake = prefs.getInt('water') ?? 0;
      dailyGoal = prefs.getInt('goal') ?? 2500;
    });
  }

  // Convert date into simple format
  String getDateString(DateTime date) {
    return "${date.year}-${date.month}-${date.day}";
  }

  // Save data locally
  Future<void> saveWaterData() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setInt('water', waterIntake);
    await prefs.setInt('goal', dailyGoal);
    await prefs.setString('date', getDateString(DateTime.now()));
  }

  // Add water
  void addWater(int amount) {
    setState(() {
      waterIntake += amount;

      records.insert(
        0,
        WaterRecord(
          amount: amount,
          time: DateTime.now(),
        ),
      );
    });

    saveWaterData();

    if (waterIntake >= dailyGoal) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("🎉 Daily hydration goal completed!"),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  // Remove latest entry
  void undoLastDrink() {
    if (records.isEmpty) return;

    setState(() {
      waterIntake -= records.first.amount;

      if (waterIntake < 0) {
        waterIntake = 0;
      }

      records.removeAt(0);
    });

    saveWaterData();
  }

  // Change daily goal
  Future<void> changeGoal() async {
    final controller = TextEditingController(
      text: dailyGoal.toString(),
    );

    final newGoal = await showDialog<int>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Set Daily Goal"),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: "Daily water goal",
              suffixText: "ml",
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("Cancel"),
            ),
            FilledButton(
              onPressed: () {
                final value = int.tryParse(controller.text);

                if (value != null && value > 0) {
                  Navigator.pop(context, value);
                }
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );

    if (newGoal != null) {
      setState(() {
        dailyGoal = newGoal;
      });

      saveWaterData();
    }
  }

  // Custom water amount
  Future<void> customWaterAmount() async {
    final controller = TextEditingController();

    final amount = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Add Custom Drink",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Enter the amount of water you drank.",
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: "Water amount",
                  suffixText: "ml",
                  prefixIcon: Icon(Icons.water_drop_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    final value = int.tryParse(controller.text);

                    if (value != null && value > 0) {
                      Navigator.pop(context, value);
                    }
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(14),
                    child: Text("Add Water"),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (amount != null) {
      addWater(amount);
    }
  }

  @override
  Widget build(BuildContext context) {
    double progress = waterIntake / dailyGoal;

    if (progress > 1) {
      progress = 1;
    }

    final remaining = waterIntake >= dailyGoal ? 0 : dailyGoal - waterIntake;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "HydroFlow",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              "Daily Hydration Tracker",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.normal,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: changeGoal,
            tooltip: "Change Goal",
            icon: const Icon(Icons.settings_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Greeting
            const Text(
              "Stay Hydrated 💧",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              "Every drop counts toward a healthier you.",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 15,
              ),
            ),

            const SizedBox(height: 25),

            // Main progress card
            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1565C0),
                    Color(0xFF42A5F5),
                  ],
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.20),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    "TODAY'S PROGRESS",
                    style: TextStyle(
                      color: Colors.white70,
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 25),
                  SizedBox(
                    width: 190,
                    height: 190,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 180,
                          height: 180,
                          child: CircularProgressIndicator(
                            value: progress,
                            strokeWidth: 15,
                            backgroundColor: Colors.white24,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Colors.white,
                            ),
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.water_drop,
                              color: Colors.white,
                              size: 35,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              "$waterIntake ml",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              "of $dailyGoal ml",
                              style: const TextStyle(
                                color: Colors.white70,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              "${(progress * 100).toInt()}%",
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 25),
                  Text(
                    remaining == 0
                        ? "Goal completed! Excellent work 🎉"
                        : "$remaining ml remaining to reach your goal",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              "Quick Add",
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              "How much water did you drink?",
              style: TextStyle(color: Colors.grey),
            ),

            const SizedBox(height: 15),

            Row(
              children: [
                Expanded(
                  child: waterButton(
                    icon: Icons.local_drink,
                    amount: 200,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: waterButton(
                    icon: Icons.water_drop_outlined,
                    amount: 250,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: waterButton(
                    icon: Icons.sports_bar_outlined,
                    amount: 500,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            OutlinedButton.icon(
              onPressed: customWaterAmount,
              icon: const Icon(Icons.add),
              label: const Text("Enter Custom Amount"),
            ),

            const SizedBox(height: 30),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Today's Activity",
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (records.isNotEmpty)
                  TextButton.icon(
                    onPressed: undoLastDrink,
                    icon: const Icon(Icons.undo),
                    label: const Text("Undo"),
                  ),
              ],
            ),

            const SizedBox(height: 10),

            if (records.isEmpty)
              Container(
                padding: const EdgeInsets.all(30),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  children: [
                    Icon(
                      Icons.water_drop_outlined,
                      size: 50,
                      color: Colors.blueGrey,
                    ),
                    SizedBox(height: 10),
                    Text(
                      "No water recorded yet",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "Add your first glass of water above.",
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              )
            else
              ...records.map(
                (record) => activityCard(record),
              ),

            const SizedBox(height: 25),

            // Health tip
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFE3F2FD),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    color: Colors.blue,
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "Hydration Tip\nDrink water regularly throughout the day instead of waiting until you feel thirsty.",
                      style: TextStyle(
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          addWater(250);
        },
        icon: const Icon(Icons.add),
        label: const Text("250 ml"),
      ),
    );
  }

  // ----------------------------------------------------------
  // QUICK WATER BUTTON
  // ----------------------------------------------------------

  Widget waterButton({
    required IconData icon,
    required int amount,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        addWater(amount);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 18,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: Colors.blue.shade100,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 30,
              color: Colors.blue,
            ),
            const SizedBox(height: 8),
            Text(
              "$amount ml",
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ----------------------------------------------------------
  // ACTIVITY CARD
  // ----------------------------------------------------------

  Widget activityCard(WaterRecord record) {
    final hour = record.time.hour > 12
        ? record.time.hour - 12
        : record.time.hour == 0
            ? 12
            : record.time.hour;

    final minute = record.time.minute.toString().padLeft(2, '0');

    final period = record.time.hour >= 12 ? "PM" : "AM";

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: const Color(0xFFE3F2FD),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.water_drop,
              color: Colors.blue,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "+${record.amount} ml",
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "$hour:$minute $period",
                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.check_circle,
            color: Colors.green,
          ),
        ],
      ),
    );
  }
}
