package com.example.hyderationapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
