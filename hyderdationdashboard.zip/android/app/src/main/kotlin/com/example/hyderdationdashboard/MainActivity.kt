package com.example.hyderdationdashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
