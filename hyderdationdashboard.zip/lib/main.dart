import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const SmartWaterApp());
}

class SmartWaterApp extends StatelessWidget {
  const SmartWaterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Water Tracker',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0277BD),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5FAFF),
      ),
      home: const WaterTrackerPage(),
    );
  }
}

class WaterTrackerPage extends StatefulWidget {
  const WaterTrackerPage({super.key});

  @override
  State<WaterTrackerPage> createState() => _WaterTrackerPageState();
}

class _WaterTrackerPageState extends State<WaterTrackerPage> {
  // Daily goal in milliliters
  int dailyGoal = 2000;

  // Total water consumed today
  int totalWater = 0;

  // Number of water entries
  int entryCount = 0;

  // Controller for user input
  final TextEditingController waterController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadData();
  }

  @override
  void dispose() {
    waterController.dispose();
    super.dispose();
  }

  // ------------------------------------------------------
  // CALCULATIONS
  // ------------------------------------------------------

  int get remainingWater {
    int remaining = dailyGoal - totalWater;

    if (remaining < 0) {
      return 0;
    }

    return remaining;
  }

  double get progress {
    if (dailyGoal == 0) {
      return 0;
    }

    double value = totalWater / dailyGoal;

    // CircularProgressIndicator should not exceed 1
    return value > 1 ? 1 : value;
  }

  int get completionPercentage {
    if (dailyGoal == 0) {
      return 0;
    }

    return ((totalWater / dailyGoal) * 100).round();
  }

  // ------------------------------------------------------
  // LOCAL STORAGE
  // ------------------------------------------------------

  Future<void> saveData() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setInt('totalWater', totalWater);
    await prefs.setInt('entryCount', entryCount);
  }

  Future<void> loadData() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      totalWater = prefs.getInt('totalWater') ?? 0;
      entryCount = prefs.getInt('entryCount') ?? 0;
    });
  }

  // ------------------------------------------------------
  // ADD WATER
  // ------------------------------------------------------

  void addWater() {
    // Convert entered text into integer
    final int? amount = int.tryParse(waterController.text.trim());

    // INPUT VALIDATION
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a water amount greater than 0 mL.',
          ),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );

      return;
    }

    setState(() {
      totalWater += amount;
      entryCount++;
    });

    waterController.clear();

    saveData();

    // Remove keyboard
    FocusScope.of(context).unfocus();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$amount mL added successfully! 💧'),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ------------------------------------------------------
  // QUICK ADD
  // ------------------------------------------------------

  void quickAdd(int amount) {
    setState(() {
      totalWater += amount;
      entryCount++;
    });

    saveData();
  }

  // ------------------------------------------------------
  // RESET CONFIRMATION
  // ------------------------------------------------------

  void showResetConfirmation() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          icon: const Icon(
            Icons.warning_amber_rounded,
            color: Colors.orange,
            size: 45,
          ),
          title: const Text(
            'Reset Water Intake?',
            textAlign: TextAlign.center,
          ),
          content: const Text(
            'This will remove today\'s water intake and entry count. '
            'Are you sure you want to continue?',
            textAlign: TextAlign.center,
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              onPressed: () {
                resetWater();
                Navigator.pop(context);
              },
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );
  }

  // ------------------------------------------------------
  // RESET DATA
  // ------------------------------------------------------

  void resetWater() {
    setState(() {
      totalWater = 0;
      entryCount = 0;
    });

    saveData();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Daily water intake has been reset.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ------------------------------------------------------
  // USER INTERFACE
  // ------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'AquaTrack',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Smart Water Intake Tracker',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Reset',
            onPressed: showResetConfirmation,
            icon: const Icon(Icons.refresh_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // ------------------------------------------------
            // TOP TEXT
            // ------------------------------------------------

            const Text(
              'Today\'s Hydration',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Track every drink and reach your daily goal.',
              style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 25),

            // ------------------------------------------------
            // MAIN PROGRESS CARD
            // ------------------------------------------------

            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF01579B),
                    Color(0xFF03A9F4),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.20),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    'DAILY PROGRESS',
                    style: TextStyle(
                      color: Colors.white70,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 25),
                  SizedBox(
                    width: 190,
                    height: 190,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 180,
                          height: 180,
                          child: CircularProgressIndicator(
                            value: progress,
                            strokeWidth: 15,
                            backgroundColor: Colors.white24,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Colors.white,
                            ),
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.water_drop_rounded,
                              color: Colors.white,
                              size: 32,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              '$totalWater mL',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 29,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'of $dailyGoal mL',
                              style: const TextStyle(
                                color: Colors.white70,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              '$completionPercentage%',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    remainingWater == 0
                        ? '🎉 Daily hydration goal completed!'
                        : '$remainingWater mL remaining today',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ------------------------------------------------
            // STATISTICS
            // ------------------------------------------------

            Row(
              children: [
                Expanded(
                  child: statCard(
                    icon: Icons.water_drop_outlined,
                    title: 'Consumed',
                    value: '$totalWater mL',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: statCard(
                    icon: Icons.flag_outlined,
                    title: 'Remaining',
                    value: '$remainingWater mL',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: statCard(
                    icon: Icons.format_list_numbered,
                    title: 'Entries',
                    value: '$entryCount',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: statCard(
                    icon: Icons.percent_rounded,
                    title: 'Completed',
                    value: '$completionPercentage%',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // ------------------------------------------------
            // ADD WATER FORM
            // ------------------------------------------------

            const Text(
              'Add Water',
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Enter the amount of water you drank.',
              style: TextStyle(
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: waterController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'Example: 500',
                labelText: 'Water Amount',
                suffixText: 'mL',
                prefixIcon: const Icon(
                  Icons.local_drink_outlined,
                ),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: (_) {
                addWater();
              },
            ),

            const SizedBox(height: 15),

            SizedBox(
              height: 55,
              child: FilledButton.icon(
                onPressed: addWater,
                icon: const Icon(Icons.add_rounded),
                label: const Text(
                  'Add Water',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 25),

            // ------------------------------------------------
            // QUICK ADD
            // ------------------------------------------------

            const Text(
              'Quick Add',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                quickAddButton(250),
                const SizedBox(width: 10),
                quickAddButton(500),
                const SizedBox(width: 10),
                quickAddButton(750),
              ],
            ),

            const SizedBox(height: 25),

            // ------------------------------------------------
            // DAILY GOAL INFORMATION
            // ------------------------------------------------

            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFE1F5FE),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.lightbulb_outline_rounded,
                    color: Color(0xFF0277BD),
                    size: 30,
                  ),
                  SizedBox(width: 15),
                  Expanded(
                    child: Text(
                      'Daily Goal: 2000 mL\n'
                      'Add each drink to monitor your hydration progress.',
                      style: TextStyle(
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------
  // STATISTIC CARD
  // ------------------------------------------------------

  Widget statCard({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.blue.shade50,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: const Color(0xFF0288D1),
            size: 28,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            title,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------
  // QUICK ADD BUTTON
  // ------------------------------------------------------

  Widget quickAddButton(int amount) {
    return Expanded(
      child: OutlinedButton(
        onPressed: () {
          quickAdd(amount);
        },
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(
            vertical: 16,
          ),
        ),
        child: Column(
          children: [
            const Icon(
              Icons.water_drop_outlined,
            ),
            const SizedBox(height: 5),
            Text(
              '$amount mL',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
